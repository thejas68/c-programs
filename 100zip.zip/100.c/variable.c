#include<stdio.h>
void main()
{
 int marks;
 marks=100;
 printf("the  mmarks of student is = %d",marks);
 }
 
