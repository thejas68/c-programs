#include<stdio.h>
#include<stdlib.h>
typedef struct 
{
 char *dayName;
 int date;
 char *activity;
 }week;
 void create(week *day)
 {
day->dayName=(char *)malloc(sizeof(char)*20);
day->activity = (char*)malloc(sizeof(char)*100);
printf("Enter the day name :");
scanf("%s",day->dayName);
printf("Enter the date:");
scanf("%d",&day->date);
printf("Enter the activity for the day :");
scanf("%s",day->activity);
}
void read(week *calender,int size)
{
 int i;
 for(i=0;i<size;i++)
 {
  printf("Enter the details for the day %d : \n",i+1);
  create(&calender[i]);
  }
  }
  void display(week *calender,int size)
  { 
   int i;
   printf("\n---------------week's Activity Details:-------------\n");
   printf("---------------------------------------------------------------------\n");
   printf("Day no \t\t Dayname \t\t Date \t\t Activity\n");
   printf("---------------------------------------------------------------------\n");
   for (i=0;i<size;i++)
   { 
   printf("%d\t\t", i+1);
   printf("| %s | \t\t",calender[i].dayName);
      printf("| %d | \t\t",calender[i].date);
         printf("| %s | \t\t",calender[i].activity);
         printf("\n");
         }
         }
         int main()
         { 
         int size;
         week *calender;
         printf("Enter the numbers of days in the week");
         scanf("%d",&size);
         calender=(week *)malloc(sizeof(week)*size);
         if(calender==NULL)
         { 
         printf("Memory allocation failed,Exiting program \n");
         return 1;
         } 
         read(calender,size);
         display(calender,size);
         free(calender);
         return 0;
         }
        
     
         
