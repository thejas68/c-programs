#include<stdio.h>
void main()
{
 int marks;
 printf("Enter the marks of marks of maths exam ");
 scanf("%d",&marks);
 printf("The marks in the maths is %d",marks);
 }
 
