#include<stdio.h>
void main()
{ 
int a;
float b;
double c;
char d;
printf("The size of integer variable a is =%zu \n",sizeof(a));
printf("The size of integer variable b is =%zu \n",sizeof(b));
printf("The size of integer variable c is =%zu \n",sizeof(c));
printf("The size of integer variable d is =%zu \n",sizeof(d));
} 


