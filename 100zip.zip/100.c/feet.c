#include<stdio.h>
void main()
{
int feet,inch;
printf("enter the feet ");
scanf("%d",&feet);
inch=feet*12;
printf("the length in inches is = %d",inch);
}
