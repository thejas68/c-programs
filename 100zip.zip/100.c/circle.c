#include<stdio.h>
void main()
{
int s,area;
printf("Enter the side of the circle  ");
scanf("%d",&s);
area=3.14126*s*s;
printf("The area of the circle is %d",area);
}
