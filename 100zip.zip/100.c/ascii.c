#include<stdio.h>
void main()
{
char cha;
printf("Enter the characer \n");
scanf("%c",&cha);
printf("The ascii value of the character is =%d",cha)s;
}

