#include<stdio.h>
void main()
{
int b,h,area;
printf("Enter the breadth and height of the triangle ");
scanf("%d%d",&b,&h);
area=0.5*b*h;
printf("The area of the traingle is %d",area);
}
