#include<stdio.h>
void main()
{
int marks;
 marks=100;
 printf("the marks of uday is %d",marks);
 }
 
