#include<stdio.h>
void main()
{
int num,right;
printf("Enter the number \n");
scanf("%d",&num);
right=num % 10;
printf("the right most number is %d",right);
}

