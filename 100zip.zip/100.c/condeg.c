#include<stdio.h>
void main()
{
float deg,feh;
printf("Enter the temprerature in degree celcius");
scanf("%f",&deg);
feh=deg+273;
printf("The temperature in fehrenheit is %f",feh);
}

