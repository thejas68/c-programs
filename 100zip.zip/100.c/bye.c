#include<stdio.h>
void main()
{ 
 int a=5,b=2;
 float c;
 c=a/b;
 printf("%f",c);
 }
