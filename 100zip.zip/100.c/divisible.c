#include<stdio.h>
void main()
{
int num,res;
printf("Enter the number");
scanf("%d",&num);
res=num%7;
if (res==0)
printf("the number is divisible by 7");
else 
printf("not divisible");
} 

